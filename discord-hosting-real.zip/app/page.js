 "use client";

import { useEffect, useState } from "react";

export default function Home() {
  const [token, setToken] = useState("");
  const [file, setFile] = useState(null);
  const [hosts, setHosts] = useState([]);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function refresh() {
    const res = await fetch("/api/hosts", { cache: "no-store" });
    if (res.ok) setHosts(await res.json());
  }

  useEffect(() => { refresh(); }, []);

  async function upload() {
    if (!token.trim()) return setMessage("봇 토큰을 입력해 주세요.");
    if (!file) return setMessage("봇 파일(.zip)을 선택해 주세요.");

    setBusy(true);
    setMessage("");
    const form = new FormData();
    form.append("token", token.trim());
    form.append("file", file);

    const res = await fetch("/api/upload", { method: "POST", body: form });
    const data = await res.json();
    setBusy(false);

    if (!res.ok) return setMessage(data.error || "업로드 실패");
    setMessage("파일 업로드 완료");
    setToken("");
    setFile(null);
    document.getElementById("bot-file").value = "";
    await refresh();
  }

  async function action(id, type) {
    const res = await fetch(`/api/hosts/${id}/${type}`, { method: "POST" });
    const data = await res.json();
    setMessage(data.message || data.error || "");
    await refresh();
  }

  return (
    <main className="page">
      <section className="panel">
        <div className="hero">
          <p className="eyebrow">DISCORD BOT HOSTING</p>
          <h1>호스팅</h1>
          <p className="muted">봇 파일을 업로드하고 실행 상태를 관리하세요.</p>
        </div>

        <div className="card">
          <label>봇 토큰</label>
          <input
            type="password"
            placeholder="Discord Bot Token"
            value={token}
            onChange={(e) => setToken(e.target.value)}
            autoComplete="off"
          />

          <label>봇 파일</label>
          <input id="bot-file" type="file" accept=".zip" onChange={(e) => setFile(e.target.files?.[0] || null)} />
          <p className="hint">ZIP 안에 index.js, main.js 또는 bot.js가 있어야 합니다.</p>

          <button onClick={upload} disabled={busy}>
            {busy ? "업로드 중..." : "파일 업로드"}
          </button>

          {message && <div className="message">{message}</div>}
        </div>

        <div className="table-card">
          <div className="table-title">내 봇</div>
          {hosts.length === 0 ? (
            <div className="empty">아직 업로드한 봇이 없습니다.</div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>봇 토큰</th>
                    <th>봇 파일</th>
                    <th>실행 날짜</th>
                    <th>상태</th>
                    <th>호스팅</th>
                  </tr>
                </thead>
                <tbody>
                  {hosts.map((h) => (
                    <tr key={h.id}>
                      <td>{h.tokenMasked}</td>
                      <td>{h.fileName}</td>
                      <td>{h.startedAt ? new Date(h.startedAt).toLocaleString("ko-KR") : "-"}</td>
                      <td><span className={`status ${h.status}`}>{h.status}</span></td>
                      <td>
                        {h.status === "running" ? (
                          <button className="stop" onClick={() => action(h.id, "stop")}>X 종료</button>
                        ) : (
                          <button onClick={() => action(h.id, "start")}>호스팅 시작</button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <p className="security">
          본인이 직접 만든/신뢰하는 봇 파일만 업로드하세요. 업로드된 코드는 서버에서 실행됩니다.
        </p>
      </section>
    </main>
  );
}
