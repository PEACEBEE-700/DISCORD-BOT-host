import "./globals.css";

export const metadata = {
  title: "Discord Bot Hosting",
  description: "Discord 봇 호스팅",
};

export default function RootLayout({ children }) {
  return (
    <html lang="ko">
      <body>{children}</body>
    </html>
  );
}
