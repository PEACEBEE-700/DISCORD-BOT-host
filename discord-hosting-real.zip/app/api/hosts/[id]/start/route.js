import { startHost } from "@/lib/host-manager";
export const runtime = "nodejs";

export async function POST(_req, { params }) {
  try {
    const id = (await params).id;
    return Response.json({ message: "호스팅을 시작했습니다.", ...(await startHost(id)) });
  } catch (e) {
    return Response.json({ error: e.message || "시작 실패" }, { status: 400 });
  }
}
