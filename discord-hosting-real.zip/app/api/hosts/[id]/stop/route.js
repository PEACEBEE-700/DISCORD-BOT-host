import { stopHost } from "@/lib/host-manager";
export const runtime = "nodejs";

export async function POST(_req, { params }) {
  try {
    const id = (await params).id;
    return Response.json({ message: "호스팅을 종료했습니다.", ...stopHost(id) });
  } catch (e) {
    return Response.json({ error: e.message || "종료 실패" }, { status: 400 });
  }
}
