import { listHosts } from "@/lib/host-manager";
export const runtime = "nodejs";
export async function GET() {
  return Response.json(listHosts());
}
