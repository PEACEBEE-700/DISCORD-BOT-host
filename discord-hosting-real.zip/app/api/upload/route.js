import { createHost } from "@/lib/host-manager";
export const runtime = "nodejs";

export async function POST(req) {
  try {
    const form = await req.formData();
    const token = String(form.get("token") || "").trim();
    const file = form.get("file");

    if (!token) return Response.json({ error: "봇 토큰이 없습니다." }, { status: 400 });
    if (!(file instanceof File)) return Response.json({ error: "ZIP 파일을 선택해 주세요." }, { status: 400 });
    if (!file.name.toLowerCase().endsWith(".zip")) return Response.json({ error: "ZIP 파일만 지원합니다." }, { status: 400 });
    if (file.size > 20 * 1024 * 1024) return Response.json({ error: "ZIP은 20MB 이하만 업로드할 수 있습니다." }, { status: 400 });

    return Response.json(await createHost(token, file), { status: 201 });
  } catch (e) {
    console.error(e);
    return Response.json({ error: e.message || "업로드 실패" }, { status: 500 });
  }
}
